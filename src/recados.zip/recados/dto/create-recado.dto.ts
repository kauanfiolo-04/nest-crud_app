import { RecadoDto } from '../entities/dto.entity';

export class CreateRecadoDto extends RecadoDto implements RecadoDto {}
