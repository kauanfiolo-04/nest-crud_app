import { PartialType } from '@nestjs/mapped-types';
import { RecadoDto } from '../entities/dto.entity';

export class UpdateRecadoDto extends PartialType(RecadoDto) implements Partial<RecadoDto> {}
